package com.web.pi3s.SpringWeb.models;

import java.util.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Despensa {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    
    private int id;
    private String nome;
    private String tipo;
    private Date vencimento;
    private String unidade;
    private double valor;
    private String observacao;
    private String datainclusao;

    public Despensa() {
    }

    @OneToMany
    private List<Item> item;

    @OneToOne
    private Cliente cliente;

    public String getNome() {
        return nome;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Date getVencimento() {
        return vencimento;
    }

    public void setVencimento(Date vencimento) {
        this.vencimento = vencimento;
    }

    public String getUnidade() {
        return unidade;
    }

    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }



    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;
    }



    public String getDatainclusao() {
        return datainclusao;
    }



    public void setDatainclusao(String datainclusao) {
        this.datainclusao = datainclusao;
    }

    public List<Item> getItem() {
        return item;
    }

    public void setItem(List<Item> item) {
        this.item = item;
    }

    

    

    
    

   

    

    
    

}
