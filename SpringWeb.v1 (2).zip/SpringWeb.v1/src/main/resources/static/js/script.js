function cadastro(){
    window.location.href = "formCliente.html"
  }