package com.web.pi3s.SpringWeb.controllers;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.web.pi3s.SpringWeb.models.Cliente;
import com.web.pi3s.SpringWeb.repositorio.Clientesrespo;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ClientesController {

    @Autowired
    private Clientesrespo repo;

    // Rota que recebe um cliente a ser cadastrado

    @GetMapping("/CadastroCliente")
    public ModelAndView formCliente() {
        ModelAndView modelAndView = new ModelAndView();
        Cliente cliente = new Cliente();
        modelAndView.setViewName("cadastro/formCliente");
        modelAndView.addObject("cliente", cliente);

        return modelAndView;

    }


    
    // Rota que cadastra um cliente no banco
    @RequestMapping(value = "/CadastroCliente/salvo", method = RequestMethod.POST)
    public String salvar(Cliente c) {

        repo.save(c); // Função que executa o cadastro
        return "home/index";
    }

    ////////////////////////////////////////////////////////////////////////////////////////

    ////////////////////// Verificar se ainda seá necessário
    ////////////////////// implementação////////////////////

    // @GetMapping("/AlterarDados")
    // public ModelAndView alterarUsuario() {
    // ModelAndView modelAndView = new ModelAndView();
    // Cliente cliente = new Cliente();
    // modelAndView.setViewName("alterar/altDadosUsuario");
    // modelAndView.addObject("cliente", cliente);

    // return modelAndView;

    // }

    /////////////////////////////////////////////////////////////////////////////////

    // Rota que recebe cliente a ser alterado

    @GetMapping("/AlterarDados/{id}")
    public String alterar(@PathVariable int id, Model model) {
        Optional<Cliente> c = repo.findById(id);
        model.addAttribute("clientes", c.get());
        return "alterar/altDadosUsuario";
    }

    // Rota que altera o cliente no banco
    @RequestMapping(value = "/AlterarDados/{id}/alterar", method = RequestMethod.POST)
    public String atualizar(@PathVariable int id, Cliente c) {

        if (!repo.existsById(id)) {

            return "redirect:/AlterarDados";
        }

        repo.save(c);

        return "redirect:/ConsultarUsuario";
    }




      // Rota que mostra os clientes no banco
    @GetMapping("/ConsultarUsuario")
    public String consultarUsuario(Model model) {
        List<Cliente> clientes = (List<Cliente>) repo.findAll();
        model.addAttribute("clientes", clientes);

        return "consultas/consultaUsuario";
    }

    @RequestMapping(value = "/ConsultarUsuario/consultar", method = RequestMethod.POST)
    public String consultar(Model model, String cpf) {

        Cliente cl = this.repo.findByCpf(cpf);
        if (cl != null) {
            model.addAttribute("sucesso", "Usuário encontrado!");
            return "redirect:/ConsultarUsuario";
        }

        model.addAttribute("erro", "Usuário não encontrado!");
        return "consultas/consultaUsuario";
    }

    @GetMapping("/ConsultarUsuario/{id}/excluir")
    public String excluir(@PathVariable int id) {
        repo.deleteById(id);
        return "redirect:/ConsultarUsuario";
    }

}
