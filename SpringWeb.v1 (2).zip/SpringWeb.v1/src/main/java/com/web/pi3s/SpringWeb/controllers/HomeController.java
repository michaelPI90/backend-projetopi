package com.web.pi3s.SpringWeb.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.web.pi3s.SpringWeb.models.Cliente;
import com.web.pi3s.SpringWeb.repositorio.Clientesrespo;

@Controller
public class HomeController {
    @Autowired
    private Clientesrespo repo;

    @GetMapping("/")
    public String index(){
 

        return "home/index";
    }


    @PostMapping("/logar")
    public String logar(Model model, String email, String senha){
        
        Cliente cl = this.repo.Login(email, senha);
        if(cl != null){
            return "redirect:/logado"; //model.addAttribute("sucesso", "Usuário cadastrado!");
        }
        
        model.addAttribute("erro", "Usuário ou senha inválidos!");
        return "home/index";
    }

    @GetMapping("/logado")
    public String logado(){
 

        return "despensa/menuDespensa";
    }

}
