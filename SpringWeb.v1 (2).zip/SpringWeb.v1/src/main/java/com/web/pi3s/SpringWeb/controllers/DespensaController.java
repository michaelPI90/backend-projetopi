package com.web.pi3s.SpringWeb.controllers;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.*;
import com.web.pi3s.SpringWeb.models.Item;
import com.web.pi3s.SpringWeb.repositorio.Itemrespo;



@Controller
public class DespensaController {
    @Autowired
    private Itemrespo repoDespensa;


 
    @GetMapping("/Despensa/{id}")
    public String despensaUsuario(@PathVariable int id, Model model) {
        List<Item> i = repoDespensa.despensa(id);
        model.addAttribute("item", i);
        return "despensa/despensa";
    }

    @GetMapping("/Despensa/{id}/excluir")
    public String excluir(@PathVariable int id) {
        repoDespensa.deleteById(id);
        return "redirect:/ConsultarUsuario";
    }

    @RequestMapping(value = "/Alterar/{id}/alterar", method = RequestMethod.POST)
    public String atualizar(@PathVariable int id, Item i) {

        if (!repoDespensa.existsById(id)) {

            return "Nenhum item encontrado";
        }

        repoDespensa.save(i);

        return "redirect:/ConsultarUsuario";
    }

    @GetMapping("/Alterar/{id}")
    public String alterar(@PathVariable int id, Model model) {
        Optional<Item> i = repoDespensa.findById(id);
        model.addAttribute("item", i.get());
        return "alterar/altDadosItem";
    }

    /*@GetMapping("/Despensa")
    public String consultarUsuario(Model model) {
        List<Item> itens = (List<Item>) repoDespensa.findAll();
        model.addAttribute("item", itens);

        return "despensa/despensa";
    }*/
}
