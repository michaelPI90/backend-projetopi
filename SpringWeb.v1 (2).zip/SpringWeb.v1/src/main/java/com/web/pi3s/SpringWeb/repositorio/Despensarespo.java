package com.web.pi3s.SpringWeb.repositorio;

import org.springframework.data.repository.CrudRepository;

import com.web.pi3s.SpringWeb.models.Despensa;

public interface Despensarespo extends CrudRepository<Despensa, Integer>{
    
}
