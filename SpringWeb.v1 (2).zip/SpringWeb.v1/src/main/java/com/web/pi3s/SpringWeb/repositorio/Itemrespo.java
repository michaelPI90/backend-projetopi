package com.web.pi3s.SpringWeb.repositorio;

import java.util.*;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.web.pi3s.SpringWeb.models.Item;

public interface Itemrespo extends CrudRepository<Item, Integer>{
    

    @Query(value="select * from item where cliente_id = :id", nativeQuery = true)
    public List<Item> despensa(@Param("id") int cliente);
    

}
