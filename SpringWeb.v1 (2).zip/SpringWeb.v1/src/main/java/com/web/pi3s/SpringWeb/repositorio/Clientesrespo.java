
package com.web.pi3s.SpringWeb.repositorio;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.web.pi3s.SpringWeb.models.Cliente;
//import java.util.List;



public interface Clientesrespo extends CrudRepository<Cliente, Integer>{

   
    @Query(value="select * from cliente where email = :email and senha = :senha", nativeQuery = true)
    public Cliente Login(@Param("email") String email, @Param("senha") String senha);
    
    @Query(value="select c.cpf from cliente c where cpf = :cpf", nativeQuery = true)
    public Cliente findByCpf(@Param("cpf") String cpf);

    

}





