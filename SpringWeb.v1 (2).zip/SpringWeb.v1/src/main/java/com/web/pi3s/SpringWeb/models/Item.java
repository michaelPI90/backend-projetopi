
package com.web.pi3s.SpringWeb.models;


import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Item {
    

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    
   
    private int id;
    
    private String nome;
    private double valor;
    private int quantidade;
    private String unidade;
    private String observacao;
    
    @ManyToOne 
    private Cliente cliente;

    @ManyToOne
    private Despensa despensa;
    
    private String tipo;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date vencimento;
    private String datainclusao;


    public Item() {
    }


    

    public Item(String nome, double valor, int quantidade, String unidade, String observacao, String datainclusao,
            Cliente cliente, String tipo, Date vencimento) {
        this.nome = nome;
        this.valor = valor;
        this.quantidade = quantidade;
        this.unidade = unidade;
        this.observacao = observacao;
        this.datainclusao = datainclusao;
        this.cliente = cliente;
        this.tipo = tipo;
        this.vencimento = vencimento;
    }

    public Item(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }


    public String getNome() {
        return nome;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }


    public Date getVencimento() {
        return vencimento;
    }


    public void setVencimento(Date vencimento) {
        this.vencimento = vencimento;
    }


    public double getValor() {
        return valor;
    }


    public void setValor(double valor) {
        this.valor = valor;
    }


    public int getQuantidade() {
        return quantidade;
    }


    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }


    public String getUnidade() {
        return unidade;
    }


    public void setUnidade(String unidade) {
        this.unidade = unidade;
    }


    public String getObservacao() {
        return observacao;
    }


    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }


    public String getDatainclusao() {
        return datainclusao;
    }


    public void setDatainclusao(String datainclusao) {
        this.datainclusao = datainclusao;

    }

    




    public Cliente getCliente() {
        return cliente;
    }




    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }




    public Despensa getDespensa() {
        return despensa;
    }




    public void setDespensa(Despensa despensa) {
        this.despensa = despensa;
    }




    public String getTipo() {
        return tipo;
    }




    public void setTipo(String tipo) {
        this.tipo = tipo;
    }




    public int getId() {
        return id;
    }




    public void setId(int id) {
        this.id = id;
    }

    
    
    
    


   

    

    


}

    

    

    

    

    



    





