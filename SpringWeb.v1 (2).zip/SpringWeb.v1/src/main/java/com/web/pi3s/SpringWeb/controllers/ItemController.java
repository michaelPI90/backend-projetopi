package com.web.pi3s.SpringWeb.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import java.util.*;
import org.springframework.ui.Model;
import com.web.pi3s.SpringWeb.models.Item;
import com.web.pi3s.SpringWeb.repositorio.Itemrespo;
import com.web.pi3s.SpringWeb.models.Cliente;
import com.web.pi3s.SpringWeb.repositorio.Clientesrespo;


@Controller
public class ItemController { 

    @Autowired    
    private Itemrespo repo;

    @Autowired    
    private Clientesrespo repo2;


    /*@GetMapping("/CadastroItem")
    public ModelAndView formItem() {
        ModelAndView modelAndView = new ModelAndView();
        Item item = new Item();
        modelAndView.setViewName("cadastro/formItem");
        modelAndView.addObject("item", item);
        
        return modelAndView;
        //return "cadastro/formCliente";
}*/
    @GetMapping("/CadastroItem/{id}")
    
        public String item(@PathVariable int id, Model model){
            Optional <Cliente> c = repo2.findById(id);
            model.addAttribute("clientes", c.get());
            return "cadastro/formItem";
            
    }

    @RequestMapping(value="/CadastroItem/{id}/salvo", method=RequestMethod.POST)
    public String salvar( @PathVariable int id, Item i){
        //Cliente c = repo2.findById(id);
        //i.setCliente(c);

        
        //public Strinsalvar(Item i){
        
        repo.save(i);
        //return modelAndView;
        return "redirect:/ConsultarUsuario";
    }


}
